package data;

public interface Crear {
	
	public void CrearPersona();

}
