package data;

public class Materia {

}
