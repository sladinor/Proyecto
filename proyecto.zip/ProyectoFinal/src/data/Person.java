package data;

public abstract class Person {
	
	private String name;
	private int edad;
	
	public Person (String name, int edad)	{
		this.name=name;
		this.edad=edad;
	}
	
}
