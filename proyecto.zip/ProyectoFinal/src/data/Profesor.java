package data;

public class Profesor extends Person implements Crear{
	
	private int calificacion;
	
	public Profesor(String name, int edad) {
		super(name,edad);
	}
	
	public void CrearPersona() {
		
	}
}
