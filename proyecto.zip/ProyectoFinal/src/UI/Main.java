package UI;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Main extends Frame {
	
	private JLabel l, e;
	private JButton buscarp;
	private JButton buscarm;
	private JPanel pinicial;
	
	public Main() {
		
		JFrame frame = new JFrame();
		frame.setSize(700, 500);
		frame.setTitle("Bienvendo al califador de profesores");
		buscarp = new JButton("Profesor");
		buscarm = new JButton("Materias");
		pinicial = new JPanel();
		l = new JLabel();
		e = new JLabel();
		l.setText("Bienvendo al califador de profesores");
		e.setText("Elija la opcion que quiere buscar");
		l.setFont(new Font("Arial", 0, 24));
		e.setFont(new Font("Arial", 0, 20));
		pinicial.setLayout(null);
		pinicial.add(l);
		l.setBounds(150,35,500, 65);
		pinicial.add(e);
		e.setBounds(220,95,450, 65);
		pinicial.add(buscarp);
		buscarp.setBounds((frame.getSize().width/2)-50,frame.getSize().height/3,100,30);
		pinicial.add(buscarm);
		buscarm.setBounds((frame.getSize().width/2)-50,2*(frame.getSize().height/3),100,30);
		frame.add(pinicial);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public static void main(String[] args) {
		
		Main m = new Main();

	}

}
